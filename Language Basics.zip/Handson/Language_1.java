package Wipro;
import java.util.*;
public class Language_1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String s1,s2;
		s1 = sc.next();
		s2= sc.next();
		System.out.println(s1+" "+"Technologies"+" "+s2);
	}

}
