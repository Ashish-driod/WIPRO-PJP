package Wipro;
import java.util.*;
public class handson_2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String s1;
		s1=sc.next();
		System.out.println("Welcome "+s1);

	}

}
