package Wipro;
import java.util.*;

public class handson_3 {
	public static void main(String [] args) {
		Scanner sc = new Scanner(System.in);
		int a,b;
		a=sc.nextInt();
		b=sc.nextInt();
		int c=a+b;
		System.out.println("The sum of "+a+" and "+b+" is "+c);
	}
}
