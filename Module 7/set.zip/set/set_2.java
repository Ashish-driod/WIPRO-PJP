package set;

import java.util.*;
public class set_2 {
    public static void main(String args[]){
        HashSet<String> h = new HashSet<String>();
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of names.");
        int n = sc.nextInt();
        for(int i=0 ;i<n;i++) {
        	h.add(sc.next());
        }
        Iterator it = h.iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }
    }
}
