package set;

import java.util.*;
public class set_4 {
		
	static TreeSet<String> ts = new TreeSet<>();
	
	static void saveCountryNames(int n) {
		Scanner sc1 = new Scanner(System.in);
		System.out.println("Enter the name of "+n+" countries.");
		for(int i = 0;i<n;i++) {
			String a = new String();
			ts.add(sc1.next());
			
		}
	}
	
	static void getCountry(String s) {
		boolean flag = false;
		for(String i : ts) {
			if(i.equalsIgnoreCase(s)) {
				flag = true;
			}
		}
		if(flag) {
			System.out.println("The country exists.");
		}else {
			System.out.println("NULL");
		}
	}
	
	public static void main(String [] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("How many countries do you wish to add.");
		int n = sc.nextInt();
		saveCountryNames(n);
		
		System.out.println("Enter the name of the country you wish to search.");
		getCountry(sc.next());
		
	}
}
