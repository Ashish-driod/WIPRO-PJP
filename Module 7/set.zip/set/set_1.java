package set;

import java.util.*;
public class set_1 {
	
	static HashSet<String> H1 = new HashSet<>();
	
	static void saveCountryNames(int n) {
		Scanner sc1 = new Scanner(System.in);
		System.out.println("Enter the name of "+n+" countries.");
		for(int i = 0;i<n;i++) {
			String a = new String();
			H1.add(sc1.next());
			
		}
	}
	
	static void getCountry(String s) {
		boolean flag = false;
		for(String i : H1) {
			if(i.equalsIgnoreCase(s)) {
				flag = true;
			}
		}
		if(flag) {
			System.out.println("The country exists.");
		}else {
			System.out.println("NULL");
		}
	}
	
	
	public static void main(String [] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("How many countries do you wish to add.");
		int n = sc.nextInt();
		saveCountryNames(n);
		
		System.out.println("Enter the name of the country you wish to search.");
		getCountry(sc.next());
		
	}
}
