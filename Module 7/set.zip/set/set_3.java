package set;

import java.util.*;
public class set_3 {
	public static void main(String [] args) {
		TreeSet<String> ts = new TreeSet<String>();
		TreeSet<String> tsreverse =  new TreeSet<String>();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the total number of contents.");
		int n = sc.nextInt();
		for(int i =0;i<n;i++) {
			ts.add(sc.next());
		}
		System.out.println("Contents before reversing.");
		for(String i : ts) {
			System.out.println(i);
		}
		
		tsreverse = (TreeSet)ts.descendingSet();
		
		System.out.println("Contents after reversing.");
		
		for(String i:tsreverse) {
			System.out.println(i);
		}
		
	}
}