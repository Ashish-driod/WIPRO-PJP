package Project_Collection;

import java.util.*;

class Employee{
	String FirstName;
	String LastName;
	int mob;
	String email;
	String addr;
	
	Employee(){};
	
	Employee(String f , String l , int mob , String mail , String addr){
		FirstName = f;
		LastName = l;
		this.mob = mob;
		this.email = mail;
		this.addr = addr;
	}
	
	public String getFirstName() {
		return FirstName;
	}
	
	public String getLastName() {
		return LastName;
	}
	
	public int getMob() {
		return mob;
	}
	
	public String getEmail() {
		return email;
	}
	
	public String getAddr() {
		return addr;
	}
}

public class Project_1 {
	public static void main(String [] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of employees.");
		int n = sc.nextInt();
		
		ArrayList<Employee> al = new ArrayList<>();
		for(int i=0 ; i<n ; i++) {
			System.out.println("For Employee number "+i+1);
			System.out.println("Enter the First Name.");
			String fname = sc.next();
			System.out.println("Enter the Last Name.");
			String lname = sc.next();
			System.out.println("Enter Mobile number.");
			int mob = sc.nextInt();
			System.out.println("Enter the email ID");
			String email = sc.next();
			System.out.println("Enter the Address");
			String addr = sc.next();
			al.add(new Employee(fname, lname,mob,email,addr));
		}
		
		System.out.println("The employees are: ");
		System.out.format("%-15s %-15s %-15s %-30s %15s\n","Firstname","Lastname","Mobile","Email","Address");
		
		Iterator<Employee> it = al.iterator();
		while(it.hasNext()) {
			Employee emp = it.next();
			System.out.format("%-15s %-15s %-15s %-30s %15s\n",emp.getFirstName(),emp.getLastName(),emp.getMob(),emp.getEmail(),emp.getAddr());
		}
	}
}
