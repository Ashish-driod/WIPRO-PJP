package Map;

import java.util.*;
public class map_3 {
	public static void main(String [] args) {
		
		Properties capitals = new Properties();
		
		capitals.put("Odisha", "Bhubaneswar");
	    capitals.put("Tamil Nadu", "Chennai");
	    capitals.put("Telengana", "Hyderabad");
	    capitals.put("Rajasthan	", "Jaipur");
	    capitals.put("Punjab", "Chandigarh");
	    
	    Set States;
	    States = capitals.keySet();
	    Iterator itr = States.iterator();
	    String s;
	    
	    while(itr.hasNext()) {
	    	s = (String) itr.next();
	    	System.out.println("The capital of " + s + " is " + 
	                capitals.getProperty(s) + ".");
	    }
	}
}
