package Map;

import java.util.*;
public class map_1 {
	
	static HashMap<String,String> hm = new HashMap<>();
	static HashMap<String,String> hmcopy = new HashMap<>();
	
	
	public static HashMap<String,String> saveCountryCapital(String countryName, String Capital) {
		hm.put(countryName,Capital);
		return hm;
	}
	
	public static String getCapital(String countryName) {
		String ans = "";
		if(hm.containsKey(countryName)) {
			ans = hm.get(countryName);
		}
		return ans;
	}
	
	public static String getCountry(String capitalName) {
		String ans = "";
		Set<Map.Entry<String, String>> entries = hm.entrySet();
		for(Map.Entry<String, String> e : entries) {
			if(e.getValue().equalsIgnoreCase(capitalName)) {
				ans = e.getKey();
			}
		}
		return ans;
	}
	
	public static HashMap<String,String> getCopy(HashMap<String,String> hm2){
		Set<Map.Entry<String,String>> entries = hm2.entrySet();
		for(Map.Entry<String,String> e : entries) {
			String country = e.getKey();
			String capital = e.getValue();
			hmcopy.put(capital, country);
		}
		return hmcopy;
	}
	
	public static ArrayList<String> getList(HashMap<String,String> hm2){
		
		Set<String> keySet = hm2.keySet();
		ArrayList<String> listOfKeys = new ArrayList<String>(keySet);
		
		return listOfKeys;
	}
	
	
	
	public static void main(String [] args) {
		Scanner sc = new Scanner(System.in);
		
		saveCountryCapital("India", "Delhi");
		saveCountryCapital("United Kingdom", "London");
		saveCountryCapital("UAE", "Abu Dhabi");
		saveCountryCapital("Australia", "Sydney");
		saveCountryCapital("USA", "Washington DC");
		
		System.out.println(getCapital("United Kingdom"));
		System.out.println(getCapital("USA"));
		System.out.println("\n");
		System.out.println("\n");
		HashMap<String, String> ans = getCopy(hm);
		System.out.println("HashMap with capital as the key and country as the value.");
		Set<Map.Entry<String,String>> entries = ans.entrySet();
		for(Map.Entry<String,String> e : entries) {
			System.out.println(e.getKey()+"\t"+e.getValue());
		}
		
		
	}
}
