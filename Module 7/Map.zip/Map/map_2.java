package Map;

import java.util.*;
public class map_2 {
	public static void main(String [] args) {
		HashMap<String, Integer> hm = new HashMap<>();
		hm.put("a",10);
		hm.put("b",20);
		hm.put("c",30);
		
		if(hm.containsKey("a"))
            System.out.println("Found");
        else
            System.out.println("Not Found");
        
        if(hm.containsValue("India"))
            System.out.println("Found");
        else
            System.out.println("Not Found");
        
        Set set = hm.entrySet();
        
        Iterator it = set.iterator();
        while(it.hasNext()){
            Map.Entry m1 = (Map.Entry)it.next();
            System.out.println(m1.getKey() + " : "+m1.getValue());
        }
	}
}
