package Map;

import java.util.*;
public class map_4 {
	public static void main(String [] args) {
		HashMap<String, Integer> hm = new HashMap<>();
		hm.put("Ashish",123456);
		hm.put("Pooja",556985);
		hm.put("Smita",123456);
		hm.put("Sanjeeb", 4544848);
		
		if(hm.containsKey("Ashish"))
            System.out.println("Found");
        else
            System.out.println("Not Found");
        
        if(hm.containsValue(556985))
            System.out.println("Found");
        else
            System.out.println("Not Found");
        
        Set set = hm.entrySet();
        
        Iterator it = set.iterator();
        while(it.hasNext()){
            Map.Entry m1 = (Map.Entry)it.next();
            System.out.println(m1.getKey() + " : "+m1.getValue());
        }
	}
}
