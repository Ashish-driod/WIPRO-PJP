package List;

import java.util.*;
public class List_3 {
	public static void main(String [] args) {
		Scanner sc = new Scanner(System.in);
		ArrayList<String> al = new ArrayList<>();
		System.out.println("Enter five Words.");
		for(int i=0;i<5;i++) {
			al.add(sc.next());
		}
		display d = new display();
		d.printAll(al);
		
	}
}

class display{
	static void printAll(ArrayList<String> a) {
		Iterator<String> i = a.iterator();
		while(i.hasNext()) {
			System.out.println(i.next());
		}
	}
}
