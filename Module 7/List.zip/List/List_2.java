package List;

import java.util.*;
import java.io.*;

class Employee{
	int empid;
	String empName;
	String email;
	String gender;
	float salary;
	Employee(int empid, String empName , String email , String gender, float salary){
		this.empid = empid;
		this.empName = empName;
		this.email = email;
		this.gender = gender ;
		this.salary = salary;
	}
	Employee(){
		
	}
	void getEmployeeDetails() {
		System.out.println("The details are ");
		System.out.println("Employee ID - "+empid+" Employee name - "+empName+" Email ID - "+email+" Gender - "+gender+" Salary - "+salary);
	}
	
	 public int getEmpId(){
	        return empid;
	    }
	    
	    public String getName(){
	        return empName;
	    }
	    
	    public float getSalary(){
	        return salary;
	    }
	
}

class EmployeeDB{
    ArrayList<Employee> al = new ArrayList();
    
    boolean addEmployee(Employee e){
        return al.add(e);
    }
    
    boolean deleteEmployee(int empId){
        boolean flag = false;
        Iterator<Employee> it = al.iterator();
        while(it.hasNext()){
            Employee e = it.next();
            if(e.getEmpId()==empId){
                flag = true;
                it.remove();
            }
        }
        return flag;
    }
    
    public String showPaySlip(int empId){
        Iterator<Employee> it = al.iterator();
        String s = "Not found";
        while(it.hasNext()){
            Employee e = it.next();
            if(e.getEmpId()==empId){
                s = e.getName()+" payslip : "+ e.getSalary();
            }
        }
        return s;
    }
    
   
}

public class List_2 {
    public static void main(String[] args) {
        Employee e = new Employee();
        EmployeeDB e1 = new EmployeeDB();
        Employee emp1 = new Employee(1, "Ashish", "ashish.mohanty135@gmail.com", "Male", 900000);
        Employee emp2 = new Employee(2, "George", "george@gmail.com", "Male", 7800000);
    	Employee emp3 = new Employee(3, "Clay Spencer", "clay@gmail.com", "Male", 200000);
	Employee emp4 = new Employee(4, "Raymond", "ray@gmail.com", "Male", 7895623);
        
        e1.addEmployee(emp1);
        e1.addEmployee(emp2);
        e1.addEmployee(emp3);
        e1.addEmployee(emp4);
        
        e1.deleteEmployee(2);
        System.out.println(e1.showPaySlip(1));
        
        e.getEmployeeDetails();
    }  
}