package List;

import java.util.*;
import java.io.*;
public class List_1 {
	public static void main(String [] args) {
		ArrayList<String> al = new ArrayList<>();
		System.out.println("Enter the months you want to add.");
		Scanner sc = new Scanner(System.in);
		while(sc.hasNext()) {
			al.add(sc.next());
			
		}
		System.out.println(al);
		
	}
}
