package List;

import java.util.*;
public class List_4 {
	public static void main(String [] args) {
		ArrayList<Object> al = new arraylist<>();
		try {
			al.add(56);
			al.add(20.699);
			al.add(25.6f);
			al.add("Ashish Kumar Mohanty");
		}catch(Exception e) {
			System.out.println("Exception" +e);
		}
	}
}

class arraylist<E> extends ArrayList<E>{
	
	public boolean add(E e) {
			if(e instanceof Integer || e instanceof Float || e instanceof Double) {
				super.add(e);
				return true;
			}else {
				throw new ClassCastException("Integer or float or double allowed.");
			}
	}
}
