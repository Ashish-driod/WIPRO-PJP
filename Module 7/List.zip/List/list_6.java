package List;

import java.util.*;
public class list_6 {
    public static void main(String args[]){
        List<String> V = new Vector<String>();
        V.add("January");
        V.add("February");
        V.add("March");
        V.add("April");
        V.add("May");
        V.add("June");
        V.add("July");
        V.add("August");
        V.add("September");
        V.add("October");  
        V.add("November");
        V.add("December");
        System.out.println(V);

    }
}