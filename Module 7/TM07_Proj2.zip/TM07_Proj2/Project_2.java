package Project_Collection;

import java.util.*;

class StringOps{
	
	public static void insert(ArrayList<String> al , String m) {
		al.add(m);
		System.out.println("Inserted Successfully.");
		
	}
	
	public static void search(ArrayList<String> al , String m) {
		if(al.contains(m)) {
			System.out.println("Item found in the List.");
		}else {
			System.out.println("Item not found in the List.");
		}
	}
	
	public static void delete(ArrayList<String> al , String m) {
		if(al.contains(m)) {
			al.remove(m);
			System.out.println("Item Deleted Successfully.");
		}else {
			System.out.println("Item not found in the List.");
		}
	}
	
}

public class Project_2 {
	public static void main(String [] args) {
		ArrayList<String> al = new ArrayList<>();
		Scanner sc = new Scanner(System.in);
		
		do {
			System.out.println("1. Insert");
			System.out.println("2. Search");
			System.out.println("3. Delete");
			System.out.println("4. Display");
			System.out.println("5. Exit");
			System.out.println("Enter your Choice.");
			
			int choice  = sc.nextInt();
			switch(choice) {
			case 1:
				System.out.println("Enter the item to be inserted.");
				String m = sc.next();
				StringOps.insert(al, m);
				break;
			
			case 2:
				System.out.println("Enter the item to be Searched.");
				StringOps.search(al, sc.next());
				break;
			
			case 3:
				System.out.println("Enter the item to be deleted.");
				StringOps.delete(al, sc.next());
				break;
			
			case 4:
				for(String i:al) {
					System.out.println(al);
				}
				break;
			
			}
			
		}while(true);
	}
}

